package adt.queue;

import adt.stack.Stack;
import adt.stack.StackImpl;

public class QueueUsingStack<T> implements Queue<T> {

	private Stack<T> stack1;
	private Stack<T> stack2;

	public QueueUsingStack(int size) {
		stack1 = new StackImpl<T>(size);
		stack2 = new StackImpl<T>(size);
	}

	@Override
	public void enqueue(T element) throws QueueOverflowException {
		if(isFull()){
			throw new QueueOverflowException();
		}
		if(stack1.isFull() == false){
			try{
				stack1.push(element);
			}
			catch (Exception e){

			}
		}
		else{
			try {
				stack2.push(element);
			}
			catch (Exception e){

			}
		}
	}

	@Override
	public T dequeue() throws QueueUnderflowException {
		if(isEmpty()){
			throw new QueueUnderflowException();
		}
		T element = head();
		Stack aux = stack1;
		Stack aux2 = stack1;
		int elements = 0;

		while(!aux.isEmpty()){
			try{
				aux.pop();
			}
			catch (Exception e){

			}
			elements++;

		}
		while(!aux.isFull()){
			try{
				aux.push(aux2.pop());

			}
			catch (Exception e){

			}
		}
		try {
			aux.pop();
		}
		catch (Exception e){

		}
		while(!stack1.isEmpty()){
			try{
				stack1.pop();
			}
			catch (Exception e){

			}
		}
		while(!aux.isEmpty()){
			try {
				stack1.push((T) aux.pop());
			}

			catch (Exception e){

			}

		}


		return  element;
	}

	@Override
	public T head() {
		if(isEmpty()){
			return null;
		}
		//FIXME Erro de referência nas 2 linhas abaixo
		Stack<T> aux1 = stack1;
		Stack<T> aux2 = stack1;

		int cont = 0;
		while(!aux1.isEmpty()){
			try {
				aux1.pop();

			}
			catch (Exception e){

			}
		}
		while(!aux2.isEmpty()){
			try{
				aux1.push(aux2.pop());
			}
			catch (Exception e){

			}
		}
		return aux1.top();

	}

	@Override
	public boolean isEmpty() {
		return stack1.isEmpty() && stack2.isEmpty();
	}

	@Override
	public boolean isFull() {
		return stack1.isFull() && stack2.isFull();
	}

}
