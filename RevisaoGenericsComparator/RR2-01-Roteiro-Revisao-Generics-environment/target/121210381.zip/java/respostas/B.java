package respostas;

public interface B extends A<String>{
    public String exibirString(String texto);
}
