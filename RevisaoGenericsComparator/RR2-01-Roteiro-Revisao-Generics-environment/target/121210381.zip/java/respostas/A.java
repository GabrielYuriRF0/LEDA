package respostas;

public interface A <T>{
    public void adicionar(T item);
}
